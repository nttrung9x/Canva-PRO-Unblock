# Canva-PRO
A chrome extension to use Canva PRO elements and pictures

# To install

 - Download and extract [Canva-PRO.zip](https://github.com/Fdito/Canva-PRO/blob/master/Canva_PRO.zip?raw=true)
 - Go to chrome://extensions
 - Enable developer mode
 - Click in 'Load unpacked'
 - Select the location where you extracted the zip file


You are all set, give it a go and report bugs in the issues tab

This extension will work only when using Canva in Spanish (planning to add multilanguage support)
